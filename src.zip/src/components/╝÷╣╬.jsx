// CostCard에서 그리는 지출 내역 클릭 시
// 모든 값을 가지고 Detail 페이지로 이동하기

// <-----Router.jsx----->
import React from "react";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import Home from "../pages/Home";
import Detail from "../pages/Detail";

const Router = () => {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/detail/:id/:date/:item/:amount/:description" element={<Detail />} />
        {/* Detail 컴포넌트로 이동할 때
        URL 경로에 추가 파라미터를 전달할 수 있게 함 */}
      </Routes>
    </BrowserRouter>
  );
};

export default Router;



// CostCard에서 지출 내역을 클릭했을 때,
// 해당 내역의 값들을 URL 경로에 포함시켜
// Detail 페이지로 이동

// <-----CostCard.jsx----->
import React from "react";
import { useNavigate } from "react-router-dom";

const CostCard = ({ costs, selectedMonth }) => {
  const navigate = useNavigate();

  const handleClick = (cost) => {
    const { id, date, item, amount, description } = cost;
    navigate(`/detail/${id}/${date}/${item}/${amount}/${description}`);
  };

  return (
    <>
      {costs
        .filter((cost) => selectedMonth === Number(cost.date.slice(5, 7)))
        .map((cost) => {
          return (
            <ul key={cost.id} onClick={() => handleClick(cost)}>
              <li>{cost.date}</li>
              <li>{cost.item}</li>
              <li>{cost.amount}</li>
              <li>{cost.description}</li>
            </ul>
          );
        })}
    </>
  );
};

export default CostCard;
Detail.jsx 파일 수정
Detail 컴포넌트에서 URL 경로에서 전달된 파라미터 값들을 받아와서 사용합니다.

jsx


// Detail.jsx
import React from "react";
import { useParams } from "react-router-dom";

const Detail = () => {
  const { id, date, item, amount, description } = useParams();

  return (
    <div>
      <h2>Detail Page</h2>
      <p>ID: {id}</p>
      <p>Date: {date}</p>
      <p>Item: {item}</

      
네, Detail 페이지에서 useParams가 어떻게 사용되는지 구체적으로 설명드리겠습니다.

useParams는 React Router DOM에서 제공하는 훅으로, URL 경로에 포함된 동적 파라미터 값을 가져올 수 있습니다.

앞서 우리가 Router.jsx에서 설정한 경로는 다음과 같습니다:

jsx


<Route path="/detail/:id/:date/:item/:amount/:description" element={<Detail />} />
여기서 :id, :date, :item, :amount, :description 부분이 동적 파라미터입니다. 이 값들은 CostCard 컴포넌트에서 navigate 함수를 호출할 때 전달됩니다.

jsx


// CostCard.jsx
const handleClick = (cost) => {
  const { id, date, item, amount, description } = cost;
  navigate(`/detail/${id}/${date}/${item}/${amount}/${description}`);
};
그러면 Detail 컴포넌트에서 useParams 훅을 사용하여 이 동적 파라미터 값들을 가져올 수 있습니다.

jsx


// Detail.jsx
import { useParams } from "react-router-dom";

const Detail = () => {
  const { id, date, item, amount, description } = useParams();

  return (
    <div>
      <h2>Detail Page</h2>
      <p>ID: {id}</p>
      <p>Date: {date}</p>
      <p>Item: {item}</p>
      <p>Amount: {amount}</p>
      <p>Description: {description}</p>
    </div>
  );
};
이렇게 useParams 훅을 사용하면 URL 경로에 포함된 동적 파라미터 값들을 쉽게 가져올 수 있습니다.
이를 통해 Detail 페이지에서 해당 지출 내역의 세부 정보를 표시할 수 있습니다.

그럼 useNavigate가 동작하는 방식과 어떻게 쓰였는지 설명해줘

thumbnail
공대생 이수민
네, useNavigate가 어떻게 동작하고 CostCard 컴포넌트에서 어떻게 사용되었는지 설명드리겠습니다.

useNavigate는 React Router DOM에서 제공하는 훅으로, 컴포넌트 내에서 프로그래밍적으로 URL 경로를 변경할 수 있게 해줍니다.

useNavigate의 동작 방식은 다음과 같습니다:

useNavigate 훅을 호출하면 navigate 함수를 반환합니다.
navigate 함수를 호출하면 URL 경로를 변경하고, 해당 경로에 맞는 컴포넌트를 렌더링합니다.
CostCard 컴포넌트에서는 다음과 같이 useNavigate를 사용했습니다:

jsx


// CostCard.jsx
import { useNavigate } from "react-router-dom";

const CostCard = ({ costs, selectedMonth }) => {
  const navigate = useNavigate();

  const handleClick = (cost) => {
    const { id, date, item, amount, description } = cost;
    navigate(`/detail/${id}/${date}/${item}/${amount}/${description}`);
  };

  return (
    <>
      {costs
        .filter((cost) => selectedMonth === Number(cost.date.slice(5, 7)))
        .map((cost) => {
          return (
            <ul key={cost.id} onClick={() => handleClick(cost)}>
              {/* ... */}
            </ul>
          );
        })}
    </>
  );
};
CostCard 컴포넌트에서 useNavigate 훅을 호출하여 navigate 함수를 받아옵니다.
지출 내역을 클릭하면 handleClick 함수가 호출됩니다.
handleClick 함수에서는 클릭된 지출 내역의 정보(id, date, item, amount, description)를 추출합니다.
추출한 정보를 이용하여 /detail/${id}/${date}/${item}/${amount}/${description} 형태의 URL 경로를 만들고, navigate 함수를 호출합니다.
이렇게 하면 Detail 페이지로 이동하면서 URL 경로에 지출 내역 정보가 포함됩니다.
이처럼 useNavigate 훅은 프로그래밍적으로 URL 경로를 변경할 수 있게 해주며, CostCard 컴포넌트에서는 이를 활용하여 지출 내역을 클릭했을 때 Detail 페이지로 이동하도록 구현했습니다.