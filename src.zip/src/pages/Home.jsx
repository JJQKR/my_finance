import React, { useState } from "react";
import SubmitCost from "../components/SubmitCost";
import { v4 as uuidv4 } from "uuid";

const Home = () => {
  const [formValues, setFormValues] = useState({
    id: uuidv4(),
    date: "",
    item: "",
    amount: 0,
    description: "",
  });

  const handleFormChange = (event) => {
    const { name, value } = event.target;
    setFormValues((prevValues) => ({
      ...prevValues,
      [name]: value,
    }));
  };

  // @@@@@@@ 기존 방법과 [name] : value 방법 비교해서 보기 @@@@@@@@

  return (
    <>
      <SubmitCost
        formValues={formValues}
        setFormValues={setFormValues}
      ></SubmitCost>
    </>
  );
};

export default Home;
